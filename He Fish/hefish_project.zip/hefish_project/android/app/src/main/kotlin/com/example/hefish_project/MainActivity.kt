package com.example.hefish_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
