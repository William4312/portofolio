
import 'package:flutter/material.dart';

const ColorBg = Color(0xff0EA7AE);
const ColorGrey = Color(0xff0EA7AE);